function validation() {
  
    var fname = document.getElementById("fname").value;
    if(!fname) {
        alert ("please enter First Name");
    }
    document.getElementById("fna").innerHTML=fname
    var lname = document.getElementById("lname").value;
    if(!lname) {
        alert ("please enter Last Name");
    } 
    console.log(lname);
    
    var email = document.getElementById("email").value;
    if(!email) {
        alert ("please enter email");
    }
    console.log(email)
    
    var option = document.getElementsByName('gender');
    console.log(option);
    if (!(option [0].checked || option [1].checked)) {
        alert ("Please Select Your Gender");
        console.log (option)
        return false;
    }  
  
    var phone = document.getElementById("phone").value;
    if(!phone.match(/^\d+/)) {
        alert("please enter phone");
    } else {
    console.log (phone);
    }
    
    var paddress = document.getElementById("paddress").value;
    console.log (paddress);
    var caddress = document.getElementById("caddress").value;
    console.log(caddress);
     
    var quli = document.getElementById("quli").value;
    console.log(quli);
      
    var sa = document.getElementById("sa").value;
    if(!sa.match(/^\d+/))
    {
    alert("Please only enter number (Allowed input:0-9)")
    }
    console.log(sa);
      
    var msg = document.getElementById("msg").value;
    console.log(msg);
     
    var option = document.getElementsByName('relocate');
    console.log(option);
    if (!(option [0].checked || option [1].checked)) {
        alert("yes r no");
        console.log(option)
        return false;
    }   
    var myfile = document.getElementById("myfile").value;
        if(!myfile) {
            alert("plz uplod ur file");
        } 
    console.log(myfile);
   }

